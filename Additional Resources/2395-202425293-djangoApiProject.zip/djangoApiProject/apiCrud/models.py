from django.db import models

# Create your models here.


class Product(models.Model):
    pName = models.CharField(max_length=100)
    pBrand = models.CharField(max_length=100)
    pPrice = models.CharField(max_length=100)
    pCat = models.CharField(max_length=100)
